"""Stage-1 composition: the original D2 controller remains in charge."""
from .audit import PublicEvidenceSession


def before_reset(owner, base, episode_id):
    config = owner.map_research_config
    base.enable_public_event_capture(episode_id, capacity=config['event_capacity'])
    owner.map_research_session = PublicEvidenceSession(config, base.get_public_vehicle_specs(),
                                                     base.get_public_control_contract())


def consume(owner):
    session = owner.map_research_session
    if not session.valid:
        return
    try:
        events = owner.env.read_public_events(session.adapter.cursor)
    except ValueError as error:
        session.valid, session.error = False, str(error)
        session.counts['event_history_failures'] += 1
        return
    session.consume(events)


def installed(owner):
    owner.map_research_session.installed(owner.guidance)
