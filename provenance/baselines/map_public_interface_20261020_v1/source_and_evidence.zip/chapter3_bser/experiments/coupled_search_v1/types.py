from dataclasses import dataclass
from core.env.public_events import PublicEvent


@dataclass(frozen=True)
class PublicStepEvidence:
    episode_id: str
    physical_step: int
    scans: tuple[PublicEvent, ...]
    transition: PublicEvent | None

    @property
    def negative_observation_valid(self):
        return bool(self.transition and self.transition.payload.negative_observation_valid)
