# AUV-Thesis-Active：D2 / D2+B2 / D2+B3

2026-10-20 地图研发：已冻结原 D2 和公共接口两个版本，补充默认关闭的 coupled_search_v1 核心分支，
包括地图—目标耦合信念、首次发现签名与候选压缩、执行不确定性评分。默认仍使用原 D2。
核心代码与有限机制验证见 **[实现说明](docs/MAP_CORE_IMPLEMENTATION_20261020_v1.md)**；尚未开展正式性能对照或长训练。
新旧地图各自独立适应后的 ZERO/B2/B3 六组脚本已补齐，上传 GitHub、Linux 验收及正式运行命令见 **[新旧地图 Linux 实验](docs/MAP_EXPERIMENT_LINUX_20261020_v1.md)**。
本地仅完成临时模型的有限机制验证；Linux 实机与正式训练由用户按指南明确执行。
基线、接口边界及后续对照说明见 **[地图版本记录](docs/MAP_MODULE_VERSIONS.md)**。

当前入口与训练流程见 **[训练和评估指南](docs/TRAINING.md)**。
首次上传新仓库、Linux 工程验证和手动小规模试验见 **[GitHub / Linux 指南](docs/GITHUB_LINUX.md)**。
本目录重建的是原 AUV-Thesis 当前工作树的 D2 repair v2，实现行为保持一致；
训练、场景导出、D2参考评估、B2/B3检查点评估和结果汇总均在本目录完成。

```powershell
conda activate AUV
Set-Location E:\gym\code\WORKSPACE\AUV-Thesis-Active
python -m cli verify
```

`verify` 显示来源及本版本的手动研究运行准入。所有执行入口缺省只打印计划，用户加 `--execute` 才运行。
默认B2/B3配置、网络、原复合奖励、gamma=.95、4智能体及28D/3D/124D保持母版行为。
D2是零RL残差对照，不训练神经网络。来源身份独立，不直接接收旧目录checkpoint。

当前重建证据见 [REBUILD](docs/REBUILD.md)，逐文件职责见 [CODE_MAP](docs/CODE_MAP.md)。
已知奖励/障碍问题见 [KNOWN_LIMITS](docs/KNOWN_LIMITS.md)；重建不保证强化学习提升性能。
历史E0验收、正式性能结论均未通过本次重建转移。

