# AUV-Thesis-Active：D2 / D2+B2 / D2+B3

2026-10-23：修复 v3 在某个搜索器无公开安全连接时整组回退、最终健康检查失败的问题。
无路搜索器继续按原规则等待，其余可达搜索器参与新地图联合规划；健康检查保留全部要求并补充失败诊断。
问题复现、新版本验证及独立 RUN 命令见 **[路径约束修复说明](docs/MAP_ROUTE_HEALTH_FIX_20261023.md)**。

2026-10-22：新增 **coupled_search_bounded_v3**：长期体素地图、64 步原始观测窗口、窗口边界联合信念和局部恢复。
提供 32/64/128 步、v2 与三项消融的独立原生训练配置。当前实验入口和分析方法见 **[有界地图实现与实验](docs/MAP_BOUNDED_V3_20261022.md)**。
这是明确标识的新地图近似算法；B2/B3、环境和规划规模保持原设置，旧 v2 配置与结果保留原身份。

2026-10-22：新增 **新地图等价计算缓存**，复用单次构造内的求交结果、回合内扫描预处理和已验证兼容结果。
求交内核、历史与采样规模保持原样；实现、独立对照及计时限制见 **[缓存实现说明](docs/MAP_CACHE_IMPLEMENTATION_20261022.md)**。
当前为有限工程验证，不代表 Linux 长程超时已完全解决。

2026-10-21：新增 **coupled_search_v2 持续运行修复**，公开射线约束几何补全、
完整历史恢复、每步新评分与不可用时明确失败。旧版本和实验结果保持原身份；
修复内容、验收要求及新 RUN 约束见 **[持续运行修复说明](docs/MAP_PERSISTENCE_FIX_20261021.md)**。

2026-10-20 地图研发记录：已冻结原 D2 和公共接口两个版本，补充默认关闭的地图核心分支，
包括地图—目标耦合信念、首次发现签名与候选压缩、执行不确定性评分。默认仍使用原 D2。
核心代码与有限机制验证见 **[实现说明](docs/MAP_CORE_IMPLEMENTATION_20261020_v1.md)**；尚未开展正式性能对照或长训练。
新旧地图各自独立适应后的 ZERO/B2/B3 六组脚本已补齐；当前为 4 个 RL 组 × 2 种子 × 300 ep，附固定验证集收敛诊断和 HTML 曲线，上传 GitHub、Linux 验收及正式运行命令见 **[新旧地图 Linux 实验](docs/MAP_EXPERIMENT_LINUX_20261020_v1.md)**。
本地仅完成临时模型的有限机制验证；Linux 实机与正式训练由用户按指南明确执行。
基线、接口边界及后续对照说明见 **[地图版本记录](docs/MAP_MODULE_VERSIONS.md)**。

当前入口与训练流程见 **[训练和评估指南](docs/TRAINING.md)**。
首次上传新仓库、Linux 工程验证和手动小规模试验见 **[GitHub / Linux 指南](docs/GITHUB_LINUX.md)**。
本目录重建的是原 AUV-Thesis 当前工作树的 D2 repair v2，实现行为保持一致；
训练、场景导出、D2参考评估、B2/B3检查点评估和结果汇总均在本目录完成。

```powershell
conda activate AUV
Set-Location E:\gym\code\WORKSPACE\AUV-Thesis-Active
python -m cli verify
```

`verify` 显示来源及本版本的手动研究运行准入。所有执行入口缺省只打印计划，用户加 `--execute` 才运行。
默认B2/B3配置、网络、原复合奖励、gamma=.95、4智能体及28D/3D/124D保持母版行为。
D2是零RL残差对照，不训练神经网络。来源身份独立，不直接接收旧目录checkpoint。

当前重建证据见 [REBUILD](docs/REBUILD.md)，逐文件职责见 [CODE_MAP](docs/CODE_MAP.md)。
已知奖励/障碍问题见 [KNOWN_LIMITS](docs/KNOWN_LIMITS.md)；重建不保证强化学习提升性能。
历史E0验收、正式性能结论均未通过本次重建转移。

