# Active 重建交付

当前状态：**MANUAL_RESEARCH_READY**。当前来源：`954f773a96b297ad8af3ec49eeabf969bf9b2326bdba67ea03c39d3044941f4f`。
日期：2026-10-19。母版HEAD为7510ca9006a620c0b52db5563e41b10c15e3fc43，加已复核未提交修复，
母版review为cc4c346efc19abc45d03d899d0dbe386eeac394028ee13f8e2ff36506b13df07。

用户本次明确要求Active独立完成论文训练，保留当前D2/D2+B2/B3行为，无论性能优劣。
因此建立本目录自己的来源和重建凭据，允许用户手动执行正常研究训练，而不是继续只开放机制模式。
母版原来源门禁、历史manifest和历史E0状态保持原样；本次不沿用/改写它们的验收。

## 保持一致的范围

- 共享core相对第一次Active提炼快照全部原字节不变；与母版的等价性由独立轨迹和更新对照验证；当前模型、Replay、Runtime、B3编码器与执行门控主体不变。
- Trainer的初始化、真实run_episode、采样、更新内循环和外层回合调度AST不变。
- 默认环境/分配/在线配置、B2/B3配置与原提炼母版相同；奖励、gamma=.95、网络尺寸、LR、tau、128/256的batch/warmup和4/2调度不变。
- 组织路径、发行来源、checkpoint外层身份及评估记录有明确新身份；旧checkpoint不会被重命名成Active版本。
- D2只有零残差参考评估；当前B2/B3使用repair-v2身份，不自动切回旧Linux未修复版本。

## 补齐的功能

场景导出保留母版物理任务，显式把validation/smoke_validation映射为eval/smoke_eval；
D2/B2/B3共用指标记录；评估结束重新核验来源；机制评估限制场景数/总步数；
汇总只接收带完成凭据和匹配哈希的结果。新增固定计划、多种子手动调度和相应互斥锁。
每个入口默认打印计划，加--execute才执行。正常研究训练/评估通过本版本独立重建凭据放行。

## 实际本地验证

| 项目 | 结果 |
|---|---|
|独立母版和重建版，对D2/B2/B3各4种场景|逐步观测/动作/物理状态/奖励/done/Replay一致，差异列表为空|
|真实batch128，一轮4智能体更新与状态恢复|损失、模型、Adam和target摘要与母版逐字节一致|
|31个当前定向测试|全部通过，无failure/error/skip；初版临时目录和测试fixture错误保留记录|
|机制Suite完整闭环|B2/B3各8步、4轮更新；D2与两个模型评估、配对/CSV汇总通过|
|结束来源负对照|只在临时副本改来源，真实一步评估被拒绝且没有成功凭据|
|普通研究模式CLI|4步、2轮更新；不加mechanism-check保存/默认加载/评估/与D2汇总通过|
|真实场景导出|物理场景与母版相同，只有显式角色/导出元数据变化|
|正常规模计划|准备了3个seed的7个任务计划，1000回合/400上限保持；未执行该长训练|
|来源隔离|新运行进程禁止读取母版生产代码/配置后仍通过|

本轮原/新独立对照共154步，机制Suite35步，正常研究模式6步，总计195个环境步；
训练回合共7个，每个临时模型最多4轮完整更新。均为新模型，只恢复本轮自己的临时checkpoint。
工具验证使用低batch/warmup的显式fixture触发更新，不修改正式配置。不是收敛或论文性能结果。

## 证据及限制

当前 [receipt](../verification/rebuild/receipt.json)绑定六项来源/结构/回归/对照/入口/检查点凭据。
原始长trace和临时模型留在原仓库tmp，不作为Active运行依赖；本目录保存必要的紧凑证据与原始哈希。
当前源演进在 [rebuild_evolution](../provenance/rebuild_evolution.json)，旧manifest与旧提炼证据保存在history。

这是当前固定来源快照的本地验证，不是CI、已提交版本的clean-clone或历史E0验证。
保持performance_passed=false。完整状态空间、其他设备/库版本及长期学习稳定性没有因此得到证明。
[已知奖励/障碍风险](KNOWN_LIMITS.md)继续保留，后续优化应采用明确的新版本与公平对照。
正式论文结论需基于用户后续手动训练和独立评估，而不是本次工程检查。


## 新仓库传输与 Linux 验证补充

本次只改变 Git 字节传输规则和验证工具；118 个运行代码/配置文件相对上一重建版逐字节不变。
新增 7 个传输负对照后，当前本地测试为 38 项全部通过。B2/B3 机制闭环 35 物理步，
另有普通研究模式 4 步训练与 2 步评估；本轮共 41 步、3 个临时训练回合，没有长训练。
上表中的母版独立对照是上一版已测结果，本版通过运行文件字节一致性保留该证据，不冒充重新运行。
所有上一版门禁/manifest/报告均原字节保存在 verification/history/rebuild_20261019_v1。

实测旧 Git 属性会在暂存时改变 32 个文件的哈希；新属性在 autocrlf=true/false 两种检出条件下
均保持原字节。这里只运行 Git index/checkout-index，没有创建提交，也没有执行真正的 Linux 克隆。
Linux 命令会要求用户指定的新提交、干净 Git 状态、完整包哈希及新的真实平台验证。
使用说明见 [GitHub/Linux](GITHUB_LINUX.md)，本轮证据见
[publication](../verification/publication/checks.json) 和 [transport](../verification/publication/transport.json)。
